require('dotenv').config();
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const { stadiums, getStadiumById, generateSeatKeys, calculateSeatPrice } = require('./src/data/stadiums');

const app = express();
const PORT = process.env.PORT || 3000;

// Database setup
const db = new sqlite3.Database(path.join(__dirname, 'database.db'), (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
  }
});

// Helper function to run queries as promises
function query(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    home_team TEXT NOT NULL,
    away_team TEXT NOT NULL,
    home_team_ar TEXT NOT NULL,
    away_team_ar TEXT NOT NULL,
    home_team_flag TEXT,
    away_team_flag TEXT,
    stadium TEXT NOT NULL,
    stadium_ar TEXT NOT NULL,
    stadium_id INTEGER DEFAULT 1,
    city TEXT NOT NULL,
    city_ar TEXT NOT NULL,
    match_date TEXT NOT NULL,
    image TEXT,
    description TEXT,
    description_ar TEXT,
    stage TEXT NOT NULL,
    stage_ar TEXT NOT NULL,
    min_price REAL NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    available_percentage INTEGER NOT NULL DEFAULT 100,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL,
    section_id TEXT NOT NULL,
    row_id TEXT NOT NULL,
    seat_number TEXT NOT NULL,
    price REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'available',
    reserved_by TEXT,
    reserved_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL,
    country TEXT NOT NULL,
    notes TEXT,
    match_id INTEGER NOT NULL,
    selected_seats TEXT NOT NULL,
    total_price REAL NOT NULL,
    payment_status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (match_id) REFERENCES matches(id)
  );

  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    title_ar TEXT NOT NULL,
    content TEXT NOT NULL,
    content_ar TEXT NOT NULL,
    image TEXT,
    is_published INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL UNIQUE,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS visitors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    match_id INTEGER,
    visited_at TEXT NOT NULL DEFAULT (datetime('now')),
    completed_order INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (match_id) REFERENCES matches(id)
  );

  CREATE TABLE IF NOT EXISTS admin_credentials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Handle admin routes - serve index.html with special handling
app.get('/admin-login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Admin credentials
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'worldcup2026';
const ADMIN_TOKEN = 'wc2026-admin-token-secure';

// Telegram notification function
async function sendTelegramNotification(order) {
  const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;
  
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) return;
  
  try {
    const message = `
🎫 *طلب تذكرة جديد / New Ticket Order*

👤 *الاسم / Name:* ${order.customer_name}
📞 *الهاتف / Phone:* ${order.phone}
📧 *البريد / Email:* ${order.email}
🌍 *الدولة / Country:* ${order.country}
⚽ *المباراة / Match:* ${order.match_name || 'N/A'}
💺 *المقاعد / Seats:* ${order.selected_seats}
💰 *السعر / Price:* $${order.total_price}
🕒 *الوقت / Time:* ${order.created_at}
🔖 *رقم الطلب / Order #:* ${order.id}
    `.trim();

    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
        parse_mode: 'Markdown'
      })
    });
  } catch (err) {
    console.error('Telegram notification failed:', err);
  }
}

// Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Admin login
app.post('/api/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    // Check if admin credentials exist in database
    const admin = await query('SELECT * FROM admin_credentials WHERE username = ?', [username]);
    
    if (admin.length === 0) {
      // If no admin exists, create default admin from env
      const defaultPassword = ADMIN_PASSWORD;
      const hashedPassword = await bcrypt.hash(defaultPassword, 10);
      await run('INSERT INTO admin_credentials (username, password_hash) VALUES (?, ?)', [ADMIN_USERNAME, hashedPassword]);
      
      // Verify the password
      const isValid = await bcrypt.compare(password, hashedPassword);
      if (isValid) {
        return res.json({ token: ADMIN_TOKEN, message: 'Login successful' });
      }
    } else {
      // Verify password against hash
      const isValid = await bcrypt.compare(password, admin[0].password_hash);
      if (isValid) {
        return res.json({ token: ADMIN_TOKEN, message: 'Login successful' });
      }
    }
    
    return res.status(401).json({ error: 'Invalid credentials' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Matches routes
app.get('/api/matches', async (req, res) => {
  try {
    const { search, sortBy, sortOrder } = req.query;
    
    let matches = await query('SELECT * FROM matches ORDER BY sort_order DESC, match_date ASC');
    
    if (search) {
      const s = search.toLowerCase();
      matches = matches.filter(m =>
        m.home_team.toLowerCase().includes(s) ||
        m.away_team.toLowerCase().includes(s) ||
        m.home_team_ar.includes(s) ||
        m.away_team_ar.includes(s) ||
        m.stadium.toLowerCase().includes(s) ||
        m.city.toLowerCase().includes(s)
      );
    }
    
    if (sortBy === 'price') {
      matches.sort((a, b) => sortOrder === 'desc' ? b.min_price - a.min_price : a.min_price - b.min_price);
    } else if (sortBy === 'date') {
      matches.sort((a, b) => sortOrder === 'desc' 
        ? new Date(b.match_date).getTime() - new Date(a.match_date).getTime()
        : new Date(a.match_date).getTime() - new Date(b.match_date).getTime()
      );
    }
    
    res.json(matches);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/matches', async (req, res) => {
  try {
    const {
      homeTeam, awayTeam, homeTeamAr, awayTeamAr,
      homeTeamFlag, awayTeamFlag, stadium, stadiumAr,
      stadiumId, city, cityAr, matchDate, image, description,
      descriptionAr, stage, stageAr, minPrice, isActive, availablePercentage, sortOrder
    } = req.body;
    
    // Get max sort_order if not provided
    let order = sortOrder;
    if (order === undefined || order === null) {
      const maxOrder = await get('SELECT MAX(sort_order) as max FROM matches');
      order = (maxOrder?.max || 0) + 1;
    }
    
    const params = [
      homeTeam, awayTeam, homeTeamAr, awayTeamAr,
      homeTeamFlag || '', awayTeamFlag || '', stadium, stadiumAr,
      stadiumId || 1, city, cityAr, matchDate, image || '', description || '',
      descriptionAr || '', stage, stageAr, minPrice || 0,
      isActive !== undefined ? isActive : 1,
      availablePercentage !== undefined ? availablePercentage : 100,
      order
    ];
    
    const result = await run(`
      INSERT INTO matches (
        home_team, away_team, home_team_ar, away_team_ar,
        home_team_flag, away_team_flag, stadium, stadium_ar,
        stadium_id, city, city_ar, match_date, image, description,
        description_ar, stage, stage_ar, min_price, is_active, available_percentage, sort_order
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, params);
    
    // Generate tickets for this match
    const match = await get('SELECT * FROM matches WHERE id = ?', [result.lastID]);
    if (match) {
      const stadiumData = getStadiumById(match.stadium_id || 1);
      if (stadiumData) {
        const basePrice = minPrice || 100;
        for (const section of stadiumData.sections) {
          for (const row of section.rows) {
            for (let i = 1; i <= row.seats; i++) {
              const price = basePrice * row.priceMultiplier;
              await run(`
                INSERT INTO tickets (match_id, section_id, row_id, seat_number, price, status)
                VALUES (?, ?, ?, ?, ?, 'available')
              `, [result.lastID, section.id, row.id, `${row.id}-${i}`, price]);
            }
          }
        }
      }
    }
    
    res.status(201).json(match);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reorder match (move up or down)
app.post('/api/matches/:id/reorder', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { direction } = req.body; // 'up' or 'down'
    
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    if (!direction) return res.status(400).json({ error: 'Direction required' });
    
    const match = await get('SELECT * FROM matches WHERE id = ?', [id]);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    
    const currentOrder = match.sort_order || 0;
    
    if (direction === 'up') {
      // Move up = decrease sort_order (higher in the list)
      // Find the match with the next LOWER sort_order
      const prevMatch = await get('SELECT * FROM matches WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1', [currentOrder]);
      if (!prevMatch) return res.json({ success: true, message: 'Already at top' });
      
      // Swap sort_order values
      const tempOrder = prevMatch.sort_order;
      await run('UPDATE matches SET sort_order = ? WHERE id = ?', [currentOrder, prevMatch.id]);
      await run('UPDATE matches SET sort_order = ? WHERE id = ?', [tempOrder, id]);
      
      res.json({ success: true, message: 'Moved up' });
    } else if (direction === 'down') {
      // Move down = increase sort_order (lower in the list)
      // Find the match with the next HIGHER sort_order
      const nextMatch = await get('SELECT * FROM matches WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1', [currentOrder]);
      if (!nextMatch) return res.json({ success: true, message: 'Already at bottom' });
      
      // Swap sort_order values
      const tempOrder = nextMatch.sort_order;
      await run('UPDATE matches SET sort_order = ? WHERE id = ?', [currentOrder, nextMatch.id]);
      await run('UPDATE matches SET sort_order = ? WHERE id = ?', [tempOrder, id]);
      
      res.json({ success: true, message: 'Moved down' });
    } else {
      res.status(400).json({ error: 'Invalid direction. Use "up" or "down"' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/matches/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    const match = await get('SELECT * FROM matches WHERE id = ?', [id]);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    
    res.json(match);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.patch('/api/matches/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    const match = await get('SELECT * FROM matches WHERE id = ?', [id]);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    
    const updates = [];
    const values = [];
    
    const fields = {
      home_team: 'homeTeam',
      away_team: 'awayTeam',
      home_team_ar: 'homeTeamAr',
      away_team_ar: 'awayTeamAr',
      home_team_flag: 'homeTeamFlag',
      away_team_flag: 'awayTeamFlag',
      stadium: 'stadium',
      stadium_ar: 'stadiumAr',
      city: 'city',
      city_ar: 'cityAr',
      match_date: 'matchDate',
      image: 'image',
      description: 'description',
      description_ar: 'descriptionAr',
      stage: 'stage',
      stage_ar: 'stageAr',
      min_price: 'minPrice',
      is_active: 'isActive',
      available_percentage: 'availablePercentage'
    };
    
    for (const [dbField, reqField] of Object.entries(fields)) {
      if (req.body[reqField] !== undefined) {
        updates.push(`${dbField} = ?`);
        values.push(req.body[reqField]);
      }
    }
    
    if (updates.length > 0) {
      values.push(id);
      await run(`UPDATE matches SET ${updates.join(', ')} WHERE id = ?`, values);
    }
    
    const updatedMatch = await get('SELECT * FROM matches WHERE id = ?', [id]);
    res.json(updatedMatch);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/matches/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    await run('DELETE FROM matches WHERE id = ?', [id]);
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Tickets routes
app.get('/api/matches/:id/tickets', async (req, res) => {
  try {
    const matchId = parseInt(req.params.id);
    if (isNaN(matchId)) return res.status(400).json({ error: 'Invalid ID' });
    
    const match = await get('SELECT * FROM matches WHERE id = ?', [matchId]);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    
    const tickets = await query('SELECT * FROM tickets WHERE match_id = ? ORDER BY section_id, row_id, seat_number', [matchId]);
    
    res.json(tickets);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reserve tickets (for checkout)
app.post('/api/tickets/reserve', async (req, res) => {
  try {
    const { matchId, seatKeys, sessionId } = req.body;
    
    if (!matchId || !seatKeys || !Array.isArray(seatKeys) || seatKeys.length === 0) {
      return res.status(400).json({ error: 'Invalid request' });
    }
    
    // Check if all seats are available
    for (const seatKey of seatKeys) {
      const [sectionId, rowId, seatNum] = seatKey.split('-');
      const ticket = await get(
        'SELECT * FROM tickets WHERE match_id = ? AND section_id = ? AND row_id = ? AND seat_number = ?',
        [matchId, sectionId, rowId, seatNum]
      );
      
      if (!ticket) {
        return res.status(404).json({ error: `Seat ${seatKey} not found` });
      }
      
      if (ticket.status !== 'available') {
        return res.status(409).json({ error: `Seat ${seatKey} is no longer available` });
      }
    }
    
    // Reserve all seats
    for (const seatKey of seatKeys) {
      const [sectionId, rowId, seatNum] = seatKey.split('-');
      await run(
        'UPDATE tickets SET status = ?, reserved_by = ?, reserved_at = datetime("now") WHERE match_id = ? AND section_id = ? AND row_id = ? AND seat_number = ?',
        ['reserved', sessionId, matchId, sectionId, rowId, seatNum]
      );
    }
    
    res.json({ success: true, reserved: seatKeys });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Release reserved tickets
app.post('/api/tickets/release', async (req, res) => {
  try {
    const { matchId, seatKeys, sessionId } = req.body;
    
    if (!matchId || !seatKeys || !Array.isArray(seatKeys)) {
      return res.status(400).json({ error: 'Invalid request' });
    }
    
    for (const seatKey of seatKeys) {
      const [sectionId, rowId, seatNum] = seatKey.split('-');
      await run(
        'UPDATE tickets SET status = ?, reserved_by = NULL, reserved_at = NULL WHERE match_id = ? AND section_id = ? AND row_id = ? AND seat_number = ? AND reserved_by = ?',
        ['available', matchId, sectionId, rowId, seatNum, sessionId]
      );
    }
    
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Confirm purchase (change status from reserved to sold)
app.post('/api/tickets/confirm', async (req, res) => {
  try {
    const { matchId, seatKeys } = req.body;
    
    if (!matchId || !seatKeys || !Array.isArray(seatKeys)) {
      return res.status(400).json({ error: 'Invalid request' });
    }
    
    for (const seatKey of seatKeys) {
      const [sectionId, rowId, seatNum] = seatKey.split('-');
      await run(
        'UPDATE tickets SET status = ? WHERE match_id = ? AND section_id = ? AND row_id = ? AND seat_number = ?',
        ['sold', matchId, sectionId, rowId, seatNum]
      );
    }
    
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get seats by section for a match
app.get('/api/matches/:id/seats', async (req, res) => {
  try {
    const matchId = parseInt(req.params.id);
    const { section } = req.query;
    
    if (isNaN(matchId)) return res.status(400).json({ error: 'Invalid ID' });
    
    const match = await get('SELECT * FROM matches WHERE id = ?', [matchId]);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    
    let tickets;
    if (section) {
      tickets = await query(
        'SELECT * FROM tickets WHERE match_id = ? AND section_id = ? ORDER BY section_id, row_id, seat_number',
        [matchId, section]
      );
    } else {
      tickets = await query(
        'SELECT * FROM tickets WHERE match_id = ? ORDER BY section_id, row_id, seat_number',
        [matchId]
      );
    }
    
    // Group by section and row
    const grouped = {};
    for (const ticket of tickets) {
      if (!grouped[ticket.section_id]) {
        grouped[ticket.section_id] = { section: ticket.section_id, rows: {} };
      }
      if (!grouped[ticket.section_id].rows[ticket.row_id]) {
        grouped[ticket.section_id].rows[ticket.row_id] = [];
      }
      grouped[ticket.section_id].rows[ticket.row_id].push(ticket);
    }
    
    res.json(grouped);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get stadium data
app.get('/api/stadiums', (req, res) => {
  res.json(stadiums);
});

app.get('/api/stadiums/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const stadium = getStadiumById(id);
  if (!stadium) return res.status(404).json({ error: 'Stadium not found' });
  res.json(stadium);
});

app.patch('/api/tickets/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    const ticket = await get('SELECT * FROM tickets WHERE id = ?', [id]);
    if (!ticket) return res.status(404).json({ error: 'Ticket not found' });
    
    const updates = [];
    const values = [];
    
    const fields = {
      category: 'category',
      category_ar: 'categoryAr',
      seat_number: 'seatNumber',
      section: 'section',
      row: 'row',
      price: 'price',
      status: 'status'
    };
    
    for (const [dbField, reqField] of Object.entries(fields)) {
      if (req.body[reqField] !== undefined) {
        updates.push(`${dbField} = ?`);
        values.push(req.body[reqField]);
      }
    }
    
    if (updates.length > 0) {
      values.push(id);
      await run(`UPDATE tickets SET ${updates.join(', ')} WHERE id = ?`, values);
    }
    
    const updatedTicket = await get('SELECT * FROM tickets WHERE id = ?', [id]);
    res.json(updatedTicket);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/tickets/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    await run('DELETE FROM tickets WHERE id = ?', [id]);
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Orders routes
app.get('/api/orders', async (req, res) => {
  try {
    const { status } = req.query;
    
    let orders = await query('SELECT * FROM orders ORDER BY created_at DESC');
    
    if (status) {
      orders = orders.filter(o => o.payment_status === status);
    }
    
    // Enrich with match name
    const matchIds = [...new Set(orders.map(o => o.match_id))];
    const matches = matchIds.length > 0 
      ? await query(`SELECT * FROM matches WHERE id IN (${matchIds.map(() => '?').join(',')})`, matchIds)
      : [];
    const matchMap = new Map(matches.map(m => [m.id, m]));
    
    const result = orders.map(o => {
      const match = matchMap.get(o.match_id);
      return {
        ...o,
        match_name: match ? `${match.home_team} vs ${match.away_team}` : null
      };
    });
    
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const {
      customerName, phone, email, country, notes,
      matchId, selectedSeats, totalPrice
    } = req.body;
    
    const result = await run(`
      INSERT INTO orders (
        customer_name, phone, email, country, notes,
        match_id, selected_seats, total_price, payment_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    `, [customerName, phone, email, country, notes, matchId, selectedSeats, totalPrice]);
    
    const order = await get('SELECT * FROM orders WHERE id = ?', [result.lastID]);
    
    // Get match info for Telegram
    const match = await get('SELECT * FROM matches WHERE id = ?', [matchId]);
    
    const orderWithMatch = {
      ...order,
      match_name: match ? `${match.home_team} vs ${match.away_team}` : null
    };
    
    // Fire-and-forget Telegram notification
    sendTelegramNotification(orderWithMatch);
    
    res.status(201).json(orderWithMatch);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/orders/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    const order = await get('SELECT * FROM orders WHERE id = ?', [id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    
    const match = await get('SELECT * FROM matches WHERE id = ?', [order.match_id]);
    
    res.json({
      ...order,
      match_name: match ? `${match.home_team} vs ${match.away_team}` : null
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.patch('/api/orders/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    const order = await get('SELECT * FROM orders WHERE id = ?', [id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    
    const { paymentStatus } = req.body;
    
    if (paymentStatus !== undefined) {
      await run('UPDATE orders SET payment_status = ? WHERE id = ?', [paymentStatus, id]);
    }
    
    const updatedOrder = await get('SELECT * FROM orders WHERE id = ?', [id]);
    const match = await get('SELECT * FROM matches WHERE id = ?', [updatedOrder.match_id]);
    
    res.json({
      ...updatedOrder,
      match_name: match ? `${match.home_team} vs ${match.away_team}` : null
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Posts routes
app.get('/api/posts', async (req, res) => {
  try {
    const posts = await query('SELECT * FROM posts ORDER BY created_at DESC');
    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/posts', async (req, res) => {
  try {
    const { title, titleAr, content, contentAr, image, isPublished } = req.body;
    
    const result = await run(`
      INSERT INTO posts (title, title_ar, content, content_ar, image, is_published)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [title, titleAr, content, contentAr, image, isPublished !== undefined ? isPublished : 1]);
    
    const post = await get('SELECT * FROM posts WHERE id = ?', [result.lastID]);
    res.status(201).json(post);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.patch('/api/posts/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    const post = await get('SELECT * FROM posts WHERE id = ?', [id]);
    if (!post) return res.status(404).json({ error: 'Post not found' });
    
    const updates = [];
    const values = [];
    
    const fields = {
      title: 'title',
      title_ar: 'titleAr',
      content: 'content',
      content_ar: 'contentAr',
      image: 'image',
      is_published: 'isPublished'
    };
    
    for (const [dbField, reqField] of Object.entries(fields)) {
      if (req.body[reqField] !== undefined) {
        updates.push(`${dbField} = ?`);
        values.push(req.body[reqField]);
      }
    }
    
    if (updates.length > 0) {
      values.push(id);
      await run(`UPDATE posts SET ${updates.join(', ')} WHERE id = ?`, values);
    }
    
    const updatedPost = await get('SELECT * FROM posts WHERE id = ?', [id]);
    res.json(updatedPost);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/posts/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });
    
    await run('DELETE FROM posts WHERE id = ?', [id]);
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Stats routes
app.get('/api/stats/summary', async (req, res) => {
  try {
    const matches = await query('SELECT * FROM matches');
    const orders = await query('SELECT * FROM orders');
    const tickets = await query('SELECT * FROM tickets');
    const posts = await query('SELECT * FROM posts');
    
    const pendingOrders = orders.filter(o => o.payment_status === 'pending').length;
    const confirmedOrders = orders.filter(o => o.payment_status === 'confirmed').length;
    const cancelledOrders = orders.filter(o => o.payment_status === 'cancelled').length;
    const totalRevenue = orders
      .filter(o => o.payment_status === 'confirmed')
      .reduce((sum, o) => sum + o.total_price, 0);
    const availableTickets = tickets.filter(t => t.status === 'available').length;
    
    res.json({
      totalMatches: matches.length,
      totalOrders: orders.length,
      pendingOrders,
      confirmedOrders,
      cancelledOrders,
      totalRevenue,
      availableTickets,
      totalPosts: posts.length
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/stats/recent-orders', async (req, res) => {
  try {
    const orders = await query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 10');
    const matches = await query('SELECT * FROM matches');
    const matchMap = new Map(matches.map(m => [m.id, m]));
    
    const result = orders.map(o => {
      const match = matchMap.get(o.match_id);
      return {
        ...o,
        match_name: match ? `${match.home_team} vs ${match.away_team}` : null
      };
    });
    
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/stats/featured-matches', async (req, res) => {
  try {
    const matches = await query('SELECT * FROM matches WHERE is_active = 1');
    
    const upcoming = matches
      .filter(m => new Date(m.match_date) >= new Date())
      .sort((a, b) => new Date(a.match_date).getTime() - new Date(b.match_date).getTime())
      .slice(0, 6);
    
    if (upcoming.length === 0) {
      const all = matches
        .sort((a, b) => new Date(b.match_date).getTime() - new Date(a.match_date).getTime())
        .slice(0, 6);
      return res.json(all);
    }
    
    res.json(upcoming);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Settings routes (Admin only)
app.get('/api/settings', async (req, res) => {
  try {
    const settings = await query('SELECT * FROM settings');
    const settingsMap = {};
    settings.forEach(s => {
      settingsMap[s.key] = s.value;
    });
    res.json(settingsMap);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/settings/:key', async (req, res) => {
  try {
    const { key } = req.params;
    const { value } = req.body;
    
    const existing = await get('SELECT * FROM settings WHERE key = ?', [key]);
    
    if (existing) {
      await run('UPDATE settings SET value = ?, updated_at = datetime("now") WHERE key = ?', [value, key]);
    } else {
      await run('INSERT INTO settings (key, value) VALUES (?, ?)', [key, value]);
    }
    
    const setting = await get('SELECT * FROM settings WHERE key = ?', [key]);
    res.json(setting);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Visitors routes (Admin only)
app.get('/api/visitors', async (req, res) => {
  try {
    const visitors = await query('SELECT * FROM visitors ORDER BY visited_at DESC');
    const matches = await query('SELECT * FROM matches');
    const matchMap = new Map(matches.map(m => [m.id, m]));
    
    const result = visitors.map(v => {
      const match = matchMap.get(v.match_id);
      return {
        ...v,
        match_name: match ? `${match.home_team} vs ${match.away_team}` : null
      };
    });
    
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/visitors', async (req, res) => {
  try {
    const { sessionId, matchId } = req.body;
    
    await run('INSERT INTO visitors (session_id, match_id) VALUES (?, ?)', [sessionId, matchId]);
    
    res.status(201).json({ message: 'Visitor tracked' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.patch('/api/visitors/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { completedOrder } = req.body;
    
    await run('UPDATE visitors SET completed_order = ? WHERE session_id = ?', [completedOrder ? 1 : 0, sessionId]);
    
    res.json({ message: 'Visitor updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Change admin password
app.post('/api/admin/change-password', async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    // Get current admin credentials
    const admin = await query('SELECT * FROM admin_credentials LIMIT 1');
    
    if (admin.length === 0) {
      return res.status(404).json({ error: 'Admin not found' });
    }
    
    // Verify current password
    const isValid = await bcrypt.compare(currentPassword, admin[0].password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }
    
    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    // Update password
    await run('UPDATE admin_credentials SET password_hash = ?, updated_at = datetime("now") WHERE id = ?', [hashedPassword, admin[0].id]);
    
    res.json({ message: 'Password changed successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Serve frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
